﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyClass10
{
    internal class PokerGameMain
    {
        static void Main()
        {
            Pokergame Poker = new Pokergame();

            
            //Poker.ComputerCardSet();
            
            Poker.matching();
        }
        
    }
}
